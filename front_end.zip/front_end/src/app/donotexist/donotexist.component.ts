import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';


@Component({
  selector: 'app-donotexist',
  templateUrl: './donotexist.component.html',
  styleUrls: ['./donotexist.component.css']
})
export class DoNotExistComponent implements OnInit {



  constructor() { 


  }

  ngOnInit(): void {
  
  }
 
}