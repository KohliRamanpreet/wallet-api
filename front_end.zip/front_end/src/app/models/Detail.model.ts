import { loginComponent } from '../login/login.component';

export class Detail
{
    userName: String;
    fullName: String;
    pass: String;
    accNumber: String;
    eMail: String;
    pNumber: String

}