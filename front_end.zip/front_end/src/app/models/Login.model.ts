export class Login

{
    id: String;
    userName: String;
    pass:String
}
