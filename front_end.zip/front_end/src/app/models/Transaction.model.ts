export class Transaction
{
    id:String;
    user:{userName:String,fullName:String,pass:String,accountNo:String,eMail:String,pNumber:755017276};
    transaction:String[];
    balance:String
}